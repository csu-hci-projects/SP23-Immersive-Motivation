using System;

namespace UnityEngine.UI
{
    [Obsolete("Not supported anymore")]
    interface IGraphicEnabledDisabled
    {
        void OnSiblingGraphicEnabledDisabled();
    }
}
