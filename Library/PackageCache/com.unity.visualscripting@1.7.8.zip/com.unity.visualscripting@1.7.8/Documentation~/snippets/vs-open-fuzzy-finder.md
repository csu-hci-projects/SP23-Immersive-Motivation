---
title: open-fuzzy-finder
---

Right-click anywhere in the Graph Editor to open the fuzzy finder.