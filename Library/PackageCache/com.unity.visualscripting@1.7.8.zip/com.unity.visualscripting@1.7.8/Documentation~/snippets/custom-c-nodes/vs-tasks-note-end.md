---
title: vs-tasks-note-end
---

The examples below are based on the previous examples for a Custom C# node. For more information, see [Create a new simple Custom C# node](../../vs-create-custom-node-empty.md).