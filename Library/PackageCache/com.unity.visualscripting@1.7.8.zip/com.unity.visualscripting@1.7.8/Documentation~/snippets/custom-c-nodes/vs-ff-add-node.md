---
title: ff-add-node
---

Right-click anywhere in the [Graph Editor](../../vs-interface-overview.md#the-graph-editor) to open the fuzzy finder. Then, select your node in the fuzzy finder to add it to your graph. 