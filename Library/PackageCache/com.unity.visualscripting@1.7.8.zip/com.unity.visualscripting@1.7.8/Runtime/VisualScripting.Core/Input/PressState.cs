namespace Unity.VisualScripting
{
    public enum PressState
    {
        Hold,
        Down,
        Up
    }
}
