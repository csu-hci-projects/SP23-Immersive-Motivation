namespace Unity.VisualScripting
{
    public interface IInitializable
    {
        void Initialize();
    }
}
