namespace Unity.VisualScripting
{
    public interface IGizmoDrawer
    {
        void OnDrawGizmos();
        void OnDrawGizmosSelected();
    }
}
