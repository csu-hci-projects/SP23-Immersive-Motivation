namespace Unity.VisualScripting
{
    public static class EditorBindingUtility
    {
        public const string FactoryMethodWarning = "This parameterless factory method is only made public for the editor. Use the constructor instead.";
    }
}
