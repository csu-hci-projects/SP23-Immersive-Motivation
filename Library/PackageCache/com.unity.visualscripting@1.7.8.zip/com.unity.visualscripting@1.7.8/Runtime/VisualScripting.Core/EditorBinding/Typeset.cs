namespace Unity.VisualScripting
{
    public enum TypeSet
    {
        AllTypes,
        RuntimeTypes,
        SettingsTypes,
        SettingsAssembliesTypes
    }
}
