namespace Unity.VisualScripting
{
    public struct EmptyEventArgs { }
}
