namespace Unity.VisualScripting
{
    public interface IGraphNesterElement : IGraphParentElement, IGraphNester { }
}
