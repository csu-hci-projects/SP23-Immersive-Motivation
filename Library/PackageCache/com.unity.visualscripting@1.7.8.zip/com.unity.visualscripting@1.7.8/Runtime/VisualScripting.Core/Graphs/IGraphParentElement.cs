namespace Unity.VisualScripting
{
    public interface IGraphParentElement : IGraphElement, IGraphParent { }
}
