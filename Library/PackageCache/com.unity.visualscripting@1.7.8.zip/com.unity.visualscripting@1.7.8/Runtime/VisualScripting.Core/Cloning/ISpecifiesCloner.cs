namespace Unity.VisualScripting
{
    public interface ISpecifiesCloner
    {
        ICloner cloner { get; }
    }
}
