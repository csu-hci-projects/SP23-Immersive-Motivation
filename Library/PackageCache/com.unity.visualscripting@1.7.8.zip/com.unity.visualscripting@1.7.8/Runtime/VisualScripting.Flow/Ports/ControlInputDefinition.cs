namespace Unity.VisualScripting
{
    public sealed class ControlInputDefinition : ControlPortDefinition, IUnitInputPortDefinition { }
}
