namespace Unity.VisualScripting
{
    public interface IUnitInputPort : IUnitPort { }
}
