namespace Unity.VisualScripting
{
    public enum StateGraphContainerType
    {
        GameObject,
        StateMachine
    }
}
