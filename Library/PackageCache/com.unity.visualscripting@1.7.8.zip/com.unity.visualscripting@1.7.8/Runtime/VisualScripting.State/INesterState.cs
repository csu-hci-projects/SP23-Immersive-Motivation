namespace Unity.VisualScripting
{
    public interface INesterState : IState, IGraphNesterElement { }
}
