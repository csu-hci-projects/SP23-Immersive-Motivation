namespace Unity.VisualScripting
{
    public enum StateExitReason
    {
        Stop,
        Branch,
        AnyBranch,
        Forced
    }
}
