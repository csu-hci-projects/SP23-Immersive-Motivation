namespace Unity.VisualScripting
{
    public enum SemanticLabel
    {
        Unspecified,
        Alpha,
        Beta,
        ReleaseCandidate,
        Final,
        Pre,
    }
}
