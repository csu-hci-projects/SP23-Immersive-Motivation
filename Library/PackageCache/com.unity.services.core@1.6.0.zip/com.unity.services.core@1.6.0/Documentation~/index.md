# Services Core
**Please consult the full manual on [https://docs.unity.com/ugs-overview/services-core-api.html](https://docs.unity.com/ugs-overview/services-core-api.html)**.