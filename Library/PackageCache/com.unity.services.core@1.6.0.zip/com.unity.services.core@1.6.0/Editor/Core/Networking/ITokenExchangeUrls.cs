using System;

namespace Unity.Services.Core.Editor
{
    internal interface ITokenExchangeUrls
    {
        string ServicesGatewayTokenExchangeUrl { get; }
    }
}
