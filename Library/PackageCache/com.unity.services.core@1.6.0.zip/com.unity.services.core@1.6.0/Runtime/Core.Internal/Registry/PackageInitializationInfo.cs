﻿using System;

namespace Unity.Services.Core.Internal
{
    class PackageInitializationInfo
    {
        public Type PackageType;

        public double InitializationTimeInSeconds;
    }
}
