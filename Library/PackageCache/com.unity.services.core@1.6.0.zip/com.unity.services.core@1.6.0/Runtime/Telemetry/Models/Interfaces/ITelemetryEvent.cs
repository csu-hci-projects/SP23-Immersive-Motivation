namespace Unity.Services.Core.Telemetry.Internal
{
    interface ITelemetryEvent {}
}
