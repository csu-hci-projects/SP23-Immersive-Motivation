com.unity.services.core copyright © 2022 Unity Technologies.

This software is subject to, and made available under, the terms of service for com.unity.services.core (see https://unity3d.com/legal/one-operate-services-terms-of-service), and is an “Operate Service” as defined therein.

Your use of the Services constitutes your acceptance of such terms. Unless expressly provided otherwise, the software under this license is made available strictly on an “AS IS” BASIS WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED. Please review the terms of service for details on these and other terms and conditions.
